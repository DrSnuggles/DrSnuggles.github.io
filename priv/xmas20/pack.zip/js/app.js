var App = (function(my){
  let anal
  my.vols = new Array(1024).fill(0)

  // onload
  //document.addEventListener('DOMContentLoaded', () => {
  my.init = async () => {
    const font = new FontFace('Codystar', 'url(css/Codystar.woff2)')
    await font.load() // wait for font to be loaded
    document.fonts.add(font) // add font

    // display svg analyzer
    fetch('img/rr.svg')
    .then(res => res.text())
    .then(txt => ana.innerHTML = txt)
    .catch(e=>console.error('Could not load SVG'))

    // init analyzer audio context on user gesture
    let userGestures = ['change', 'click', 'contextmenu', 'dblclick', 'mouseup', 'pointerup', 'reset', 'submit', 'touchend']
    userGestures.forEach(i => {
      addEventListener(i, gestureEvent, false)
    })
    function gestureEvent(){
      // detach userGesture listener
      userGestures.forEach(i => {
        removeEventListener(i, gestureEvent)
      })

      // play audio
      BassoonTracker.init(true)
      BassoonTracker.load('aud/xmasmix.mod', false, () => {
        setTimeout(()=>{
          // i guess there is something wrong with .zip support. this is called twice!!
          if (anal) return // just the first is important to me
          BassoonTracker.playSong()
          startTime = new Date().getTime()

          // create analzer
          anal = BassoonTracker.audio.context.createAnalyser()
          anal.fftSize = 256 // min=32 is enough for meter
          anal.smoothingTimeConstant = 0.85
          BassoonTracker.audio.cutOffVolume.connect(anal)

          // start the sh/now
          doLoop()

          // snow
          setTimeout(()=>{
            xmas.classList.add('fadeIn')
            snow.classList.add('fadeIn')
            Snowflake.init(document.getElementById('snow'))
          },2000)

        }, 100)
      })

    }

    // loop
    function doLoop() {
      requestAnimationFrame(doLoop)
      // bad idea to walk the buffer twice.... should get volume out of single freqs
      //console.log(getVol(), getFreqs())
      let freqs = getFreqs()
      let rects = fg.getElementsByTagName('rect') // even = upper, odd = lower
      let sum = 0
      for (let i = 22; i < freqs.length-22; i++) { //128 entries is too much to fit in 2x42 fields, shifted to mid
        sum += freqs[i] // for pulse
        if (i>41+22) {
          rects[i-22].setAttribute('y', (345 - freqs[i]* 1.2))
          rects[i-22].setAttribute('height', freqs[i]* 1.2)
        } else {
          rects[i-22].setAttribute('height', freqs[i]* 0.6)
        }
      }
      sum = sum / freqs.length
      my.vols.shift()
      my.vols.push(sum)

      // draw pulse = volume over time
      // <path id="pulse" d="M 50 229.6 L 50 229.6 L 78.5 229.6 L 107 259 L 135.5 247.8 L 164 246.4 L 192.5 249.2 L 221 240.8 L 249.5 228.2 L 278 245 L 306.5 259 L 335 257.6 L 363.5 256.2 L 392 256.2 L 420.5 249.2 L 449 242.2 L 477.5 264.6 L 506 238 L 534.5 271.6 L 563 246.4 L 591.5 247.8 L 620 254.8 L 648.5 254.8 L 677 260.4 L 705.5 250.6 L 734 252 L 762.5 247.8 L 791 240.8 L 819.5 243.6 L 848 254.8 L 876.5 256.2 L 905 268.8 L 933.5 259 L 962 231 L 990.5 229.6 L 1019 240.8 L 1047.5 242.2 L 1076 240.8 L 1104.5 247.8 L 1133 247.8 L 1161.5 250.6 L 1190 247.8 L 1218.5 246.4"></path>
      let pulseLine = ['M 50 '+ (270 - my.vols[0]*0.5) ]
      //for (let i = 1; i < my.vols.length; i++) {
      for (let i = 1; i < my.vols.length; i++) {
        pulseLine.push(' L '+ (50+i*1.15) +' '+ (270 - my.vols[i]*0.5))
      }
      pulse.setAttribute('d', pulseLine)

    }

    function getFreqs(){
      let buf = new Uint8Array(anal.frequencyBinCount)
      anal.getByteFrequencyData(buf)

      return buf
    }
    /*
    function getVol(){
      let buf = new Float32Array(anal.fftSize)
      anal.getFloatTimeDomainData(buf)

      // rms
      let sum = 0
      for (let i=0; i<buf.length; i++) {
        let x = buf[i]
        sum += x * x
      }

      return Math.sqrt(sum / buf.length)
    }
    */

  }//) // onload

  return my
}(App || {})) // app

//https://engageinteractive.co.uk/blog/5-modern-snow-effects
var Snowflake = (function() {

  var flakes
  var flakesTotal = 250
  var wind = 0
  var mouseX
  var mouseY

  function Snowflake(size, x, y, vx, vy) {
    this.size = size
    this.x = x
    this.y = y
    this.vx = vx
    this.vy = vy
    this.hit = false
    this.melt = false
    this.div = document.createElement('div')
    this.div.classList.add('snowflake')
    this.div.style.width = this.size + 'px'
    this.div.style.height = this.size + 'px'
  }

  Snowflake.prototype.move = function() {
    if (this.hit) {
      if (Math.random() > 0.995) this.melt = true
    } else {
      this.x += this.vx + Math.min(Math.max(wind, -10), 10)
      this.y += this.vy
    }

    // Wrap the snowflake to within the bounds of the page
    if (this.x > window.innerWidth + this.size) {
      this.x -= window.innerWidth + this.size
    }

    if (this.x < -this.size) {
      this.x += window.innerWidth + this.size
    }

    if (this.y > window.innerHeight + this.size) {
      this.x = Math.random() * window.innerWidth
      this.y -= window.innerHeight + this.size * 2
      this.melt = false
    }

    var dx = mouseX - this.x
    var dy = mouseY - this.y
    this.hit = !this.melt && this.y < mouseY && dx * dx + dy * dy < 2400
  };

  Snowflake.prototype.draw = function() {
    this.div.style.transform =
    this.div.style.MozTransform =
    this.div.style.webkitTransform =
      'translate3d(' + this.x + 'px' + ',' + this.y + 'px,0)'
  };

  function update() {
    for (var i = flakes.length; i--; ) {
      var flake = flakes[i]
      flake.move()
      flake.draw()
    }
    requestAnimationFrame(update)
  }

  Snowflake.init = function(container) {
    flakes = []

    for (var i = flakesTotal; i--; ) {
      var size = (Math.random() + 0.2) * 12 + 1;
      var flake = new Snowflake(
        size,
        Math.random() * window.innerWidth,
        Math.random() * window.innerHeight,
        Math.random() - 0.5,
        size * 0.3
      );
      container.appendChild(flake.div)
      flakes.push(flake)
    }

    container.onmousemove = function(event) {
      mouseX = event.clientX
      mouseY = event.clientY
      wind = (mouseX - window.innerWidth / 2) / window.innerWidth * 6
    };

    container.ontouchstart = function(event) {
      mouseX = event.targetTouches[0].clientX
      mouseY = event.targetTouches[0].clientY
      event.preventDefault()
    };

    window.ondeviceorientation = function(event) {
      if (event) {
        wind = event.gamma / 10
      }
    }

    update()
  }

  return Snowflake

}())
